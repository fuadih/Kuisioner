<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Catatan extends CI_Model
{
    public function getDosen()
    {
        $this->db->select('tbl_dosen.*, tbl_smt.kd_smt AS kd_smt, tbl_smt.semester');
        $this->db->select('tbl_dosen.*, tbl_matkul.kd_matkul AS kd_matkul, tbl_matkul.matkul');
        $this->db->join('tbl_smt', 'tbl_dosen.kd_smt = tbl_smt.kd_smt');
        $this->db->join('tbl_matkul', 'tbl_dosen.kd_matkul = tbl_matkul.kd_matkul');
        $this->db->from('tbl_dosen');
        $query = $this->db->get();
        return $query->result();
    }

    public function getMatkul()
    {
        $this->db->select('tbl_matkul.*, tbl_smt.kd_smt AS kd_smt, tbl_smt.semester');
        $this->db->join('tbl_smt', 'tbl_matkul.kd_smt = tbl_smt.kd_smt');
        $this->db->from('tbl_matkul');
        $query = $this->db->get();
        return $query->result();
    }

    public function getSmt()
    {
        $this->db->select('tbl_smt.*, tbl_thnajar.kd_thnajar AS kd_thnajar, tbl_thnajar.thn_ajar');
        $this->db->join('tbl_thnajar', 'tbl_smt.kd_thnajar = tbl_thnajar.kd_thnajar');
        $this->db->from('tbl_smt');
        $query = $this->db->get();
        return $query->result();
    }

    // SELECT ambilmk.nim, ambilmk.kodemk, mk.namamk, mk.sks, MAX(ambilmk.nilai)
    // FROM ambilmk, mk
    // WHERE ambilmk.kodemk = mk.kodemk AND ambilmk.nim = 'M0197001'
    // GROUP BY ambilmk.kodemk;

    public function getMax()
    {
        $this->db->select('tbl_kuisioner.*, tbl_dosen.nip  AS nip, tbl_dosen.dosen');
        $this->db->select('tbl_kuisioner.*, tbl_matkul.kd_matkul  AS kd_matkul, tbl_matkul.matkul');
        $this->db->select('tbl_kuisioner.*, tbl_smt.kd_smt  AS kd_smt, tbl_smt.semester');
        $this->db->select_avg('tbl_kuisioner.waktu');
        $this->db->select_avg('tbl_kuisioner.materi');
        $this->db->select_avg('tbl_kuisioner.bap');
        $this->db->select_avg('tbl_kuisioner.tugas');
        $this->db->select_avg('tbl_kuisioner.alat');
        $this->db->select_avg('tbl_kuisioner.suasana');
        $this->db->select_avg('tbl_kuisioner.kritik');
        $this->db->select_avg('tbl_kuisioner.pertemuan');
        $this->db->select_avg('tbl_kuisioner.transparansi');
        $this->db->select_avg('tbl_kuisioner.kesesuaian');
        $this->db->join('tbl_dosen', 'tbl_kuisioner.nip = tbl_dosen.nip');
        $this->db->join('tbl_matkul', 'tbl_kuisioner.kd_matkul = tbl_matkul.kd_matkul');
        $this->db->join('tbl_smt', 'tbl_kuisioner.kd_smt = tbl_smt.kd_smt');
        $this->db->from('tbl_kuisioner');


        $query = $this->db->get();
        return $query->result();
    }

    public function kuisioner()
    {
        $this->db->select('tbl_kuisioner.*, tbl_dosen.nip  AS nip, tbl_dosen.dosen');
        $this->db->select('tbl_kuisioner.*, tbl_matkul.kd_matkul  AS kd_matkul, tbl_matkul.matkul');
        $this->db->select('tbl_kuisioner.*, tbl_smt.kd_smt  AS kd_smt, tbl_smt.semester');
        $this->db->select('tbl_kuisioner.*, tbl_thnajar.kd_thnajar  AS kd_thnajar, tbl_thnajar.thn_ajar');
        $this->db->join('tbl_dosen', 'tbl_kuisioner.nip = tbl_dosen.nip');
        $this->db->join('tbl_matkul', 'tbl_kuisioner.kd_matkul = tbl_matkul.kd_matkul');
        $this->db->join('tbl_smt', 'tbl_kuisioner.kd_smt = tbl_smt.kd_smt');
        $this->db->join('tbl_thnajar', 'tbl_kuisioner.kd_thnajar = tbl_thnajar.kd_thnajar');
        $this->db->from('tbl_kuisioner');
    }

    public function getKepuasan()
    {
        $this->db->select('tbl_kepuasan.*, tbl_dosen.nip  AS nip, tbl_dosen.dosen');
        $this->db->select_avg('tbl_kepuasan.perwalian');
        $this->db->select_avg('tbl_kepuasan.kp');
        $this->db->select_avg('tbl_kepuasan.skripsi');
        $this->db->select_avg('tbl_kepuasan.penampilan');
        $this->db->select_avg('tbl_kepuasan.kritik');
        $this->db->select_avg('tbl_kepuasan.ruang');
        $this->db->select_avg('tbl_kepuasan.empati');
        $this->db->select_max('tbl_kepuasan.tahun');
        $this->db->join('tbl_dosen', 'tbl_kepuasan.nip = tbl_dosen.nip');
        $this->db->from('tbl_kepuasan');

        $query = $this->db->get();
        return $query->result();
    }

    public function view(){
        
         $result = $this->db->get('tbl_smt')->result();
    
        return $result; 
    }

    public function tahun(){
        
         $result = $this->db->get('tbl_thnajar')->result(); 
        return $result; 
    }

    public function matkul(){
        
         $result = $this->db->get('tbl_matkul')->result(); 
    
        return $result; 
    }

     public function dosen(){
        
         $result = $this->db->get('tbl_dosen')->result(); 
    
        return $result; 
    }


    public function viewBysmt($kd_smt){
        $this->db->where('kd_smt', $kd_smt);
       return $this->db->get('tbl_thnajar')->result(); 
    
    return $result; 
    }

    public function get_semester($idsmt)
    {
        $semester = "<option value='0'>Pilih Semester</option>";
        $query = $this->db->where('kd_thnajar', $idsmt)->from('tbl_smt')->get();

        foreach($query->result_array() as $data){
            $semester .= "<option value='$data[kd_smt]'>$data[semester]</option>";
        };  

        return $semester;
    }

    public function get_matkul($idmatkul)
    {
        $matkul = "<option value='0'>Pilih Matkul</option>";
        $query = $this->db->where('kd_smt', $idmatkul)->from('tbl_matkul')->get();

        foreach($query->result_array() as $data){
            $matkul .= "<option value='$data[kd_matkul]'>$data[matkul]</option>";
        };  

        return $matkul;
    }

    public function get_dosen($iddosen)
    {
        $dosen = "<option value='0'>Pilih Dosen</option>";
        $query = $this->db->where('kd_matkul', $iddosen)->from('tbl_dosen')->get();

        foreach($query->result_array() as $data){
            $dosen .= "<option value='$data[nip]'>$data[dosen]</option>";
        };  

        return $dosen;
    }
    
}
