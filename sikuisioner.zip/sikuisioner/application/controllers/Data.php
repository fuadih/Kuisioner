<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('si');
        $this->load->model('catatan');
    }

    public function mhs()
    {
        $data['title'] = 'Data Mahasiswa Sistem Informasi';
        $data['user'] = $this->db->get_where('user', ['nim' => $this->session->userdata('nim')])->row_array();

        $data['tbl_mhs'] = $this->si->tampil_data()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('data/mhs', $data);
        $this->load->view('templates/footer');
    }

    public function inputData()
    {
        $nim1 = $this->input->post('nim');
        $nama = $this->input->post('name');

        $user = $this->input->post('name', true);
        $nim = $this->input->post('nim', true);
        $pass = $this->input->post('nim');


        $mahasiswa = array(
            'name' => htmlspecialchars($user),
            'nim' => htmlspecialchars($nim),
            'image' => 'default.jpg',
            'password' => password_hash($pass, PASSWORD_DEFAULT),
            'role_id' => 2,
            'is_active' => 1,
            'date_created' => time()
        );

        $data = array(
            'nim' => $nim1,
            'name' => $nama
        );

        $this->form_validation->set_rules('name', 'Name', 'required|trim');
        $this->form_validation->set_rules('nim', 'Nim', 'required|trim', [
            'is_unique' => 'NIM ini telah di Inputkan!'
        ]);

        $this->db->insert('user', $mahasiswa);
        $this->si->input_data($data, 'tbl_mhs');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Data Mahasiswa 2016 Telah ditambah!</div>');

        redirect('data/mhs');
    }

    public function hapus($nim)
    {

        $where = array('nim' => $nim);
        $mahasiswa = array('nim' => $nim);

        $this->si->hapus_data($where, 'tbl_mhs');
        $this->db->delete('user', $mahasiswa);
        redirect('data/mhs');
    }
    function update()
    {
        $nim1 = $this->input->post('nim');
        $nim = $this->input->post('nim');
        $nama = $this->input->post('name');


        $data = array(
            'nim' => $nim1,
            'name' => $nama
        );

        $data1 = array(
            'name' => $nama
        );

        $where = array(
            'nim' => $nim1
        );

        $where1 = array(
            'nim' => $nim
        );

        $this->si->update_data($where, $data, 'tbl_mhs');
        $this->si->update_data($where1, $data1, 'user');

        redirect('data/mhs');
    }

    public function dosen()
    {
        $data['title'] = 'Data Dosen Sistem Informasi';
        $data['user'] = $this->db->get_where('user', ['nim' => $this->session->userdata('nim')])->row_array();

        $data['semester'] = $this->db->get('tbl_smt')->result_array();
        $data['matkul'] = $this->db->get('tbl_matkul')->result_array();
        $data['smt'] = $this->catatan->getDosen();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('data/dosen', $data);
        $this->load->view('templates/footer');
    }

    public function inputDosen()
    {
        $data['semester'] = $this->db->get('tbl_smt')->result_array();
        $data['matkul'] = $this->db->get('tbl_matkul')->result_array();

        $nip = $this->input->post('nip');
        $dosen = $this->input->post('dosen');
        $kd_smt = $this->input->post('kd_smt');
        $kd_matkul = $this->input->post('kd_matkul');

        $data = array(
            'nip' => $nip,
            'dosen' => $dosen,
            'kd_smt' => $kd_smt,
            'kd_matkul' => $kd_matkul
        );

        $this->form_validation->set_rules('dosen', 'Dosen', 'required|trim');
        $this->form_validation->set_rules('nip', 'Nip', 'required|trim', [
            'is_unique' => 'NIM ini telah di Inputkan!'
        ]);

        $this->si->input_data($data, 'tbl_dosen');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Data Mahasiswa 2016 Telah ditambah!</div>');

        redirect('data/dosen');
    }

    function updateDosen()
    {
        $data['semester'] = $this->db->get('tbl_smt')->result_array();
        $data['matkul'] = $this->db->get('tbl_matkul')->result_array();

        $id = $this->input->post('id');
        $nip = $this->input->post('nip');
        $dosen = $this->input->post('dosen');
        $kd_smt = $this->input->post('kd_smt');
        $kd_matkul = $this->input->post('kd_matkul');

        $data = array(
            'id' => $id,
            'nip' => $nip,
            'dosen' => $dosen,
            'kd_smt' => $kd_smt,
            'kd_matkul' => $kd_matkul
        );

        $where = array(
            'id' => $id
        );

        $this->si->update_data($where, $data, 'tbl_dosen');

        redirect('data/dosen');
    }
    public function hapusDosen($id)
    {
        $where = array('id' => $id);

        $this->si->hapus_data($where, 'tbl_dosen');
        redirect('data/dosen');
    }

    public function matkul()
    {
        $data['title'] = 'Data MataKuliah Sistem Informasi';
        $data['user'] = $this->db->get_where('user', ['nim' => $this->session->userdata('nim')])->row_array();

        $data['semester'] = $this->db->get('tbl_smt')->result_array();

        $data['smt'] = $this->catatan->getMatkul();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('data/matkul', $data);
        $this->load->view('templates/footer');
    }

    function updateMatkul()
    {
        $data['semester'] = $this->db->get('tbl_smt')->result_array();

        $matkul = $this->input->post('matkul');
        $kd_smt = $this->input->post('kd_smt');
        $kd_matkul = $this->input->post('kd_matkul');

        $data = array(
            'kd_matkul' => $kd_matkul,
            'matkul' => $matkul,
            'kd_smt' => $kd_smt
        );

        $where = array(
            'kd_matkul' => $kd_matkul
        );

        $this->si->update_data($where, $data, 'tbl_matkul');

        redirect('data/matkul');
    }

    public function inputMatkul()
    {
        $data['semester'] = $this->db->get('tbl_smt')->result_array();


        $matkul = $this->input->post('matkul');
        $kd_smt = $this->input->post('kd_smt');
        $kd_matkul = $this->input->post('kd_matkul');

        $data = array(
            'kd_matkul' => $kd_matkul,
            'matkul' => $matkul,
            'kd_smt' => $kd_smt
        );

        $this->form_validation->set_rules('dosen', 'Dosen', 'required|trim');
        $this->form_validation->set_rules('nip', 'Nip', 'required|trim', [
            'is_unique' => 'NIM ini telah di Inputkan!'
        ]);

        $this->si->input_data($data, 'tbl_matkul');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Data Mahasiswa 2016 Telah ditambah!</div>');

        redirect('data/matkul');
    }

    public function hapusMatkul($kd_matkul)
    {
        $where = array('kd_matkul' => $kd_matkul);

        $this->si->hapus_data($where, 'tbl_matkul');
        redirect('data/matkul');
    }

    public function smt()
    {
        $data['title'] = 'Data Semester Sistem Informasi';
        $data['user'] = $this->db->get_where('user', ['nim' => $this->session->userdata('nim')])->row_array();

        $data['thnajar'] = $this->db->get('tbl_thnajar')->result_array();

        $data['thn_ajar'] = $this->catatan->getSmt();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('data/smt', $data);
        $this->load->view('templates/footer');
    }

    public function inputSmt()
    {
        $data['thnajar'] = $this->db->get('tbl_thnajar')->result_array();


        $semester = $this->input->post('semester');
        // $kd_smt = $this->input->post('kd_smt');
        $kd_thnajar = $this->input->post('kd_thnajar');

        $data = array(
            'semester' => $semester,
            'kd_thnajar' => $kd_thnajar
        );

        $this->form_validation->set_rules('dosen', 'Dosen', 'required|trim');
        $this->form_validation->set_rules('nip', 'Nip', 'required|trim', [
            'is_unique' => 'NIM ini telah di Inputkan!'
        ]);

        $this->si->input_data($data, 'tbl_smt');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Data Mahasiswa 2016 Telah ditambah!</div>');

        redirect('data/smt');
    }

    function updateSmt()
    {
        $data['thnajar'] = $this->db->get('tbl_thnajar')->result_array();

        $kd_smt = $this->input->post('kd_smt');
        $semester = $this->input->post('semester');
        $kd_thnajar = $this->input->post('kd_thnajar');


        $data = array(
            'kd_smt' => $kd_smt,
            'semester' => $semester,
            'kd_thnajar' => $kd_thnajar
        );

        $where = array(
            'kd_smt' => $kd_smt
        );

        $this->si->update_data($where, $data, 'tbl_smt');

        redirect('data/smt');
    }
    public function hapusSmt($kd_smt)
    {
        $where = array('kd_smt' => $kd_smt);

        $this->si->hapus_data($where, 'tbl_smt');
        redirect('data/smt');
    }

    public function thnajar()
    {
        $data['title'] = 'Data Tahun Ajaran Sistem Informasi';
        $data['user'] = $this->db->get_where('user', ['nim' => $this->session->userdata('nim')])->row_array();

        $data['tbl_thnajar'] = $this->si->tampil_ajar()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('data/thnajar', $data);
        $this->load->view('templates/footer');
    }

    public function inputAjar()
    {
        $thn_ajar = $this->input->post('thn_ajar');

        $data = array(
            'thn_ajar' => $thn_ajar
        );

        $this->form_validation->set_rules('dosen', 'Dosen', 'required|trim');
        $this->form_validation->set_rules('nip', 'Nip', 'required|trim', [
            'is_unique' => 'NIM ini telah di Inputkan!'
        ]);

        $this->si->input_data($data, 'tbl_thnajar');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Data Mahasiswa 2016 Telah ditambah!</div>');

        redirect('data/thnajar');
    }

    function updateAjar()
    {
        $kd_thnajar = $this->input->post('kd_thnajar');
        $thn_ajar = $this->input->post('thn_ajar');

        $data = array(
            'kd_thnajar' => $kd_thnajar,
            'thn_ajar' => $thn_ajar,
        );

        $where = array(
            'kd_thnajar' => $kd_thnajar,
        );

        $this->si->update_data($where, $data, 'tbl_thnajar');

        redirect('data/thnajar');
    }
    public function hapusAjar($kd_thnajar)
    {
        $where = array('kd_thnajar' => $kd_thnajar);

        $this->si->hapus_data($where, 'tbl_thnajar');
        redirect('data/thnajar');
    }

    public function opsi()
    {
        $data['title'] = 'Data Opsi Pilihan';
        $data['user'] = $this->db->get_where('user', ['nim' => $this->session->userdata('nim')])->row_array();

        $data['opsi'] = $this->db->get('tbl_opsi')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('data/opsi', $data);
        $this->load->view('templates/footer');
    }

    public function inputOpsi()
    {
        $data['opsi'] = $this->db->get('tbl_opsi')->result_array();

        $opsi = $this->input->post('opsi');
        $nilai = $this->input->post('nilai');

        $data = array(
            'opsi' => $opsi,
            'nilai' => $nilai
        );

        $this->form_validation->set_rules('dosen', 'Dosen', 'required|trim');
        $this->form_validation->set_rules('nip', 'Nip', 'required|trim', [
            'is_unique' => 'NIM ini telah di Inputkan!'
        ]);

        $this->si->input_data($data, 'tbl_opsi');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Data Mahasiswa 2016 Telah ditambah!</div>');

        redirect('data/opsi');
    }

    public function updateOpsi()
    {
        $data['thnajar'] = $this->db->get('tbl_thnajar')->result_array();

        $kd_opsi = $this->input->post('kd_opsi');
        $opsi = $this->input->post('opsi');
        $nilai = $this->input->post('nilai');


        $data = array(
            'kd_opsi' => $kd_opsi,
            'opsi' => $opsi,
            'nilai' => $nilai
        );

        $where = array(
            'kd_opsi' => $kd_opsi,
        );

        $this->si->update_data($where, $data, 'tbl_opsi');

        redirect('data/opsi');
    }
    public function hapusOpsi($kd_opsi)
    {
        $where = array('kd_opsi' => $kd_opsi);

        $this->si->hapus_data($where, 'tbl_opsi');
        redirect('data/opsi');
    }
}
