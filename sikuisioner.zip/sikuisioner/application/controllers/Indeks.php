<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Indeks extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('si');
        $this->load->model('catatan');
    }

    public function ngajar()
    {
        $data['title'] = ' Sistem Informasi';
        $data['user'] = $this->db->get_where('user', ['nim' => $this->session->userdata('nim')])->row_array();

        $data['smt'] = $this->catatan->getMax();

        $data['tbl_kuisioner'] = $this->si->tampil_kuisioner()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('indeks/ngajar', $data);
        $this->load->view('templates/footer');
    }

    public function layanan()
    {
        $data['title'] = ' Sistem Informasi';
        $data['user'] = $this->db->get_where('user', ['nim' => $this->session->userdata('nim')])->row_array();
        $data['puas'] = $this->catatan->getKepuasan();

        $data['tbl_mhs'] = $this->si->tampil_data()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('indeks/layanan', $data);
        $this->load->view('templates/footer');
    }
}
