<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kuisioner extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('si');
        $this->load->model('catatan');
    }

    public function ajar()
    {
        $data['title'] = 'Kuisioner Evaluasi Pengajaran Sistem Informasi';
        $data['user'] = $this->db->get_where('user', ['nim' => $this->session->userdata('nim')])->row_array();

        $data['semester'] = $this->catatan->view(); 
        $data['matkul'] = $this->catatan->matkul();
        $data['dosen'] = $this->catatan->dosen();
        // $data['thnajar'] = $this->db->get('tbl_thnajar')->result_array();
        $data['thnajar'] = $this->catatan->tahun();


        $data['opsi'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi2'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi3'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi4'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi5'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi6'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi7'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi8'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi9'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi10'] = $this->db->get('tbl_opsi')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('kuisioner/ajar', $data);
        $this->load->view('templates/footer');
    }

    public function inputData()
    {
        $nim = $this->input->post('nim');
        $kd_smt = $this->input->post('kd_smt');
        $kd_matkul = $this->input->post('kd_matkul');
        $nip  = $this->input->post('nip');
        $kd_thnajar = $this->input->post('kd_thnajar');
        $waktu = $this->input->post('waktu');
        $materi = $this->input->post('materi');
        $bap = $this->input->post('bap');
        $tugas = $this->input->post('tugas');
        $alat = $this->input->post('alat');
        $suasana = $this->input->post('suasana');
        $kritik = $this->input->post('kritik');
        $pertemuan = $this->input->post('pertemuan');
        $transparansi = $this->input->post('transparansi');
        $kesesuaian = $this->input->post('kesesuaian');

        $data = array(
            'nim' => $nim,
            'kd_smt' => $kd_smt,
            'kd_matkul' => $kd_matkul,
            'nip' => $nip,
            'kd_thnajar' => $kd_thnajar,
            'waktu' => $waktu,
            'materi' => $materi,
            'bap' => $bap,
            'tugas' => $tugas,
            'alat' => $alat,
            'suasana' => $suasana,
            'kritik' => $kritik,
            'pertemuan' => $pertemuan,
            'transparansi' => $transparansi,
            'kesesuaian' => $kesesuaian

        );

        $this->form_validation->set_rules('name', 'Name', 'required|trim');
        $this->form_validation->set_rules('email', 'email', 'required|trim|is_unique[data_2016.nim]', [
            'is_unique' => 'NIM ini telah di Inputkan!'
        ]);

        $this->si->input_data($data, 'tbl_kuisioner');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Data Mahasiswa 2016 Telah ditambah!</div>');

        redirect('kuisioner/ajar');
    }

    public function kepuasan()
    {
        $data['title'] = 'Kuisioner Evaluasi Pelayanan Sistem Informasi';
        $data['user'] = $this->db->get_where('user', ['nim' => $this->session->userdata('nim')])->row_array();

        $data['dosen'] = $this->db->get('tbl_dosen')->result_array();

        $data['opsi'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi2'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi3'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi4'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi5'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi6'] = $this->db->get('tbl_opsi')->result_array();
        $data['opsi7'] = $this->db->get('tbl_opsi')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('kuisioner/kepuasan', $data);
        $this->load->view('templates/footer');
    }

    public function input()
    {
        $nim = $this->input->post('nim');
        $nip  = $this->input->post('nip');
        $perwalian = $this->input->post('perwalian');
        $kp = $this->input->post('kp');
        $skripsi = $this->input->post('skripsi');
        $penampilan = $this->input->post('penampilan');
        $kritik = $this->input->post('kritik');
        $ruang = $this->input->post('ruang');
        $empati = $this->input->post('kritik');

        $data = array(
            'nim' => $nim,
            'nip' => $nip,
            'perwalian' => $perwalian,
            'kp' => $kp,
            'skripsi' => $skripsi,
            'penampilan' => $penampilan,
            'kritik' => $kritik,
            'ruang' => $ruang,
            'empati' => $empati,
            'tahun' => 2019

        );

        $this->form_validation->set_rules('name', 'Name', 'required|trim');
        $this->form_validation->set_rules('email', 'email', 'required|trim|is_unique[data_2016.nim]', [
            'is_unique' => 'NIM ini telah di Inputkan!'
        ]);

        $this->si->input_data($data, 'tbl_kepuasan');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Data Mahasiswa 2016 Telah ditambah!</div>');

        redirect('kuisioner/kepuasan');
    }

    public function ambil_data(){ //ambil data guys di model catatan
        $modul= $this->input->post('modul');
        $id=$this->input->post('id');

        if($modul=='semester'){
            echo $this->catatan->get_semester($id);
        }elseif ($modul=='matkul') {
             echo $this->catatan->get_matkul($id);
        }elseif ($modul=='dosen') {
             echo $this->catatan->get_dosen($id);
        }

    }
}
