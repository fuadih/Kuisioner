<div class="main-content">
    <div class="header pb-8 pt-5 pt-lg-5 d-flex align-items-center">
        <!-- Top navbar -->
        <div class="container-fluid">
            <div class="form-group mb-0">
                <div class="container-fluid mt--3">
                    <div class="row">
                        <div class="col-xl-20 order-xl-1">
                            <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

                            <div class="row">
                                <div class="col-lg">

                                    <div class="card shadow mb-4">
                                        <div class="card-body">
                                            <h2 class="h3 mb-4 text-gray-800">Rata-Rata Indeks Prestasi Dosen SI Pengajaran</h2>
                                            <div class="table-responsive">
                                                <div class="box-body">
                                                    <table class="table table-hover table-bordered">

                                                        <tr>
                                                            <td scope=" rol">No</td>
                                                            <td scope="rol">Nim</th>
                                                            <td scope="rol">Semester</td>
                                                            <td scope="rol">Matakuliah</td>
                                                            <td scope="rol">Dosen</td>
                                                            <td scope="rol">waktu</td>
                                                            <td scope="rol">materi</td>
                                                            <td scope="rol">bap</td>
                                                            <td scope="rol">tugas</td>
                                                            <td scope="rol">alat</td>
                                                            <td scope="rol">suasana</td>
                                                            <td scope="rol">kritik</td>
                                                            <td scope="rol">pertemuan</td>
                                                            <td scope="rol">transparansi</td>
                                                            <td scope="rol">kesesuaian</td>
                                                        </tr>

                                                        <tbody>

                                                            <?php
                                                            $no = 1;
                                                            foreach ($smt as $sm) { ?>
                                                                <tr>
                                                                    <td scope="row"><?php echo $no++ ?></td>
                                                                    <td scope="row"><?= $sm->nim ?></td>
                                                                    <td><?= $sm->semester ?></td>
                                                                    <td><?= $sm->matkul ?></td>
                                                                    <td><?= $sm->dosen ?></td>
                                                                    <td><?= $sm->waktu ?></td>
                                                                    <td><?= $sm->materi ?></td>
                                                                    <td><?= $sm->bap ?></td>
                                                                    <td><?= $sm->tugas ?></td>
                                                                    <td><?= $sm->alat ?></td>
                                                                    <td><?= $sm->suasana ?></td>
                                                                    <td><?= $sm->kritik ?></td>
                                                                    <td><?= $sm->pertemuan ?></td>
                                                                    <td><?= $sm->transparansi ?></td>
                                                                    <td><?= $sm->kesesuaian ?></td>

                                                                </tr>
                                                            <?php } ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!-- Area Chart -->
                                        <div class="col-xl-6 col-lg-6">
                                            <div class="card shadow mb-4">
                                                <!-- Card Header - Dropdown -->
                                                <div id="rata">
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        Highcharts.chart('rata', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'Rata-Rata Indeks Pengajaran Dosen'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                    }
                }
            },
            series: [{
                name: 'Rata-Rata',
                colorByPoint: true,
                data: [{
                        name: 'Waktu',
                        y: <?= $sm->waktu ?>
                    },
                    {
                        name: 'Materi',
                        y: <?= $sm->materi ?>
                    },
                    {
                        name: 'BAP',
                        y: <?= $sm->bap ?>
                    },
                    {
                        name: 'Tugas',
                        y: <?= $sm->tugas ?>
                    },
                    {
                        name: 'Alat',
                        y: <?= $sm->alat ?>
                    },
                    {
                        name: 'Suasana',
                        y: <?= $sm->suasana ?>
                    },
                    {
                        name: 'Kritik',
                        y: <?= $sm->kritik ?>
                    },
                    {
                        name: 'Pertemuan',
                        y: <?= $sm->pertemuan ?>
                    },
                    {
                        name: 'Transparansi',
                        y: <?= $sm->transparansi ?>
                    },
                    {
                        name: 'Kesesuaian',
                        y: <?= $sm->kesesuaian ?>
                    }
                ]
            }]
        });
    </script>