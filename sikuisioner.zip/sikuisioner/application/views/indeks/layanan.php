<div class="main-content">
    <div class="header pb-8 pt-5 pt-lg-5 d-flex align-items-center">
        <!-- Top navbar -->
        <div class="container-fluid">
            <div class="form-group mb-0">
                <div class="container-fluid mt--3">
                    <div class="row">
                        <div class="col-xl-20 order-xl-1">
                            <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

                            <div class="row">
                                <div class="col-lg">

                                    <div class="card shadow mb-4">
                                        <div class="card-body">
                                            <h2 class="h3 mb-4 text-gray-800">Rata-Rata Indeks Prestasi Dosen SI Pelayanan</h2>
                                            <div class="table-responsive">
                                                <div class="box-body">
                                                    <table class="table table-hover table-bordered">

                                                        <tr>
                                                            <td scope=" rol">No</td>
                                                            <td scope="rol">Nim</th>
                                                            <td scope="rol">Dosen</td>
                                                            <td scope="rol">perwalian</td>
                                                            <td scope="rol">kp</td>
                                                            <td scope="rol">skripsi</td>
                                                            <td scope="rol">penampilan</td>
                                                            <td scope="rol">kritik</td>
                                                            <td scope="rol">ruang</td>
                                                            <td scope="rol">empati</td>
                                                            <td scope="rol">tahun</td>
                                                        </tr>

                                                        <tbody>

                                                            <?php
                                                            $no = 1;
                                                            foreach ($puas as $sm) { ?>
                                                                <tr>
                                                                    <td scope="row"><?php echo $no++ ?></td>
                                                                    <td scope="row"><?= $sm->nim ?></td>
                                                                    <td><?= $sm->dosen ?></td>
                                                                    <td><?= $sm->perwalian ?></td>
                                                                    <td><?= $sm->kp ?></td>
                                                                    <td><?= $sm->skripsi ?></td>
                                                                    <td><?= $sm->penampilan ?></td>
                                                                    <td><?= $sm->kritik ?></td>
                                                                    <td><?= $sm->ruang ?></td>
                                                                    <td><?= $sm->empati ?></td>
                                                                    <td><?= $sm->tahun ?></td>

                                                                </tr>
                                                            <?php } ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!-- Area Chart -->
                                        <div class="col-xl-6 col-lg-6">
                                            <div class="card shadow mb-4">
                                                <!-- Card Header - Dropdown -->
                                                <div id="rata">
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        Highcharts.chart('rata', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'Rata-Rata Indeks Pengajaran Dosen'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                    }
                }
            },
            series: [{
                name: 'Rata-Rata',
                colorByPoint: true,
                data: [{
                        name: 'perwalian',
                        y: <?= $sm->perwalian ?>
                    },
                    {
                        name: 'kp',
                        y: <?= $sm->kp ?>
                    },
                    {
                        name: 'skripsi',
                        y: <?= $sm->skripsi ?>
                    },
                    {
                        name: 'penampilan',
                        y: <?= $sm->penampilan ?>
                    },
                    {
                        name: 'Kritik',
                        y: <?= $sm->kritik ?>
                    },
                    {
                        name: 'ruang',
                        y: <?= $sm->ruang ?>
                    },
                    {
                        name: 'empati',
                        y: <?= $sm->empati ?>
                    }
                ]
            }]
        });
    </script>