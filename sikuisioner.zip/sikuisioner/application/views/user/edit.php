<div class="main-content">
    <div class="header pb-8 pt-5 pt-lg-7 d-flex align-items-center">
        <!-- Top navbar -->
        <div class="container-fluid">
            <div class="form-group mb-0">
                <!-- Page content -->

                <div class="container-fluid mt--3">
                    <div class="row">
                        <div class="col-xl-12 order-xl-1">
                            <div class="card bg-secondary shadow">
                                <div class="card-header bg-white border-0">
                                    <div class="row align-items-center">
                                        <div class="col-8">
                                            <h3 class="mb-0">Akun Saya</h3>
                                        </div>

                                    </div>
                                </div>
                                <div class="card-body">
                                    <form>
                                        <div class="pl-lg-4">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="row justify-content-left">
                                                        <div class="col-lg-3 order-lg-2-col-md-4">
                                                            <div class="card-profile-image ">
                                                                <img src="<?= base_url('assets/img/profile/') .  $user['image']; ?>" class="card-img">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <h6 class="heading-small text-muted mb-4"></h6>
                                            <h6 class="heading-small text-muted mb-4"></h6>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label" for="input-username">NAMA</label>
                                                        <input type="text" id="input-username" class="form-control form-control-alternative" placeholder="Username" value="<?= $user['name']; ?>" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label" for="input-email">NIM</label>
                                                        <input type="email" id="input-email" class="form-control form-control-alternative" placeholder="jesse@example.com" value="<?= $user['email']; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-0 text-right">
                                                <a href="<?= base_url('user/edit') ?>" class="btn btn-sm btn-primary">Simpan</a>
                                            </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>