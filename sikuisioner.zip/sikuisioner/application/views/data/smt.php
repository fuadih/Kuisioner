<div class="main-content">
    <div class="header pb-8 pt-5 pt-lg-5 d-flex align-items-center">
        <!-- Top navbar -->
        <div class="container-fluid">
            <div class="form-group mb-0">
                <div class="container-fluid mt--3">
                    <div class="row">
                        <div class="col-xl-20 order-xl-1">
                            <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

                            <div class="row">
                                <div class="col-lg">
                                    <?= form_open_multipart('data/inputDosen'); ?>
                                    <p><?php echo $this->session->flashdata('msg') ?></p>

                                    <a href="" class="btn btn-primary mb-2" data-toggle="modal" data-target="#newSubMenuModal">Tambah Semester Sistem Informasi</a>

                                    <table font-size="40px" class="table table-hover">

                                        <tr>
                                            <td scope="rol">No</td>
                                            <!-- <td scope="rol">Kode Semester</th> -->
                                            <td scope="rol">Semester</td>
                                            <td scope="rol">Tahun Ajar</td>
                                            <td scope="rol">Opsi</td>
                                        </tr>

                                        <tbody>

                                            <?php
                                            $no = 1;
                                            foreach ($thn_ajar as $sm) { ?>
                                                <tr>
                                                    <td scope="row"><?php echo $no++ ?></td>
                                                    <!-- <td scope="row"><?= $sm->kd_smt ?></td> -->
                                                    <td><?= $sm->semester ?></td>
                                                    <td><?= $sm->thn_ajar ?></td>

                                                    <td>
                                                        <a href="" class="badge badge-pill badge-success" data-toggle="modal" data-target="#<?= $sm->semester ?>">Edit</a>
                                                        <a href="<?= base_url('data/hapusSmt/' . $sm->kd_smt); ?>" onclick="if(confirm('Apakah anda yakin ingin menghapus data ini ??')){ value=" <?= $user['name']; ?>" }" class="badge badge-pill badge-danger">Delete</a>
                                                    </td>

                                                </tr>

                                                <!-- ------------------------------- Edit Mahasiswa ----------------------------------------------------------------------------------------------------------------------------------------- -->
                                                <div class="modal fade" id="<?= $sm->semester ?>" tabindex="-1" role="dialog" aria-labelledby="mahasiswaeditlabel" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="mahasiswaeditlabel">edit Data Matakuliah Sistem Informasi</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>

                                                            <form action="<?= base_url('data/updateSmt') ?>" method="post">
                                                                <div class="modal-body">

                                                                    <div class="form-group">
                                                                        <input type="text" class="form-control" id="kd_smt" placeholder="Kode Matkul" name="kd_smt" readonly required>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <input type="text" class="form-control" id="semester" placeholder="Semester" name="semester" required>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <select name="kd_smt" id="kd_smt" class="form-control" placeholder="semester" required>
                                                                            <option value="">-- Pilih Tahun Ajaran --</option>
                                                                            <?php foreach ($thnajar as $sm) { ?>
                                                                                <option value="<?= $sm['kd_thnajar']; ?>"><?= $sm['thn_ajar']; ?></option>
                                                                            <?php } ?>
                                                                        </select>
                                                                    </div>



                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                                                </div>
                                                            </form>

                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- ------------------------------- ------------------------------------------------------------------------------------------------------------------------------------------->

                                            <?php } ?>
                                        </tbody>
                                    </table>
                                    <!-- ------------------------------- Tambah Dosen ----------------------------------------------------------------------------------------------------------------------------------------- -->
                                    <div class="modal fade" id="newSubMenuModal" tabindex="-1" role="dialog" aria-labelledby="newSubMenuModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="newSubMenuModalLabel">Tambah Data Semester Sistem Informasi</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>

                                                <form action="<?= base_url('data/inputSmt'); ?>" method="post">
                                                    <div class="modal-body">
                                                        <!-- <div class="form-group">
                                                            <input type="text" class="form-control" id="kd_smt" placeholder="Kode Matkul" name="kd_smt" required>
                                                        </div> -->

                                                        <div class="form-group">
                                                            <input type="text" class="form-control" id="semester" placeholder="Semester" name="semester" required>
                                                        </div>

                                                        <div class="form-group">
                                                            <select name="kd_thnajar" id="kd_thnajar" class="form-control" placeholder="semester" required>
                                                                <option value="">-- Pilih Tahun Ajaran --</option>
                                                                <?php foreach ($thnajar as $sm) { ?>
                                                                    <option value="<?= $sm['kd_thnajar']; ?>"><?= $sm['thn_ajar']; ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>


                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Add</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>