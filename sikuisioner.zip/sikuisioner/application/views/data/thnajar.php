<div class="main-content">
    <div class="header pb-8 pt-5 pt-lg-5 d-flex align-items-center">
        <!-- Top navbar -->
        <div class="container-fluid">
            <div class="form-group mb-0">
                <div class="container-fluid mt--3">
                    <div class="row">
                        <div class="col-xl-20 order-xl-1">
                            <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

                            <div class="row">
                                <div class="col-lg">
                                    <?= form_open_multipart('data/inputAjar'); ?>
                                    <p><?php echo $this->session->flashdata('msg') ?></p>

                                    <a href="" class="btn btn-primary mb-2" data-toggle="modal" data-target="#newSubMenuModal">Tambah Tahun Ajaran Sistem Informasi</a>

                                    <table font-size="40px" class="table table-hover">

                                        <tr>
                                            <td scope="rol">No</td>
                                            <td scope="rol">Tahun Ajar</td>
                                            <td scope="rol">Opsi</td>
                                        </tr>

                                        <tbody>

                                            <?php
                                            $no = 1;
                                            foreach ($tbl_thnajar as $sm) { ?>
                                                <tr>
                                                    <td scope="row"><?php echo $no++ ?></td>
                                                    <td scope="row"><?= $sm->thn_ajar ?></td>

                                                    <td>
                                                        <a href="" class="badge badge-pill badge-success" data-toggle="modal" data-target="#<?php echo $sm->thn_ajar ?>">Edit</a>
                                                        <a href="<?= base_url('data/hapusAjar/' . $sm->kd_thnajar); ?>" onclick="if(confirm('Apakah anda yakin ingin menghapus data ini ??')){ value=" <?= $user['name']; ?>" }" class="badge badge-pill badge-danger">Delete</a>
                                                    </td>

                                                </tr>

                                                <!-- ------------------------------- Edit Mahasiswa ----------------------------------------------------------------------------------------------------------------------------------------- -->

                                                <div class="modal fade" id="<?php echo $sm->thn_ajar ?>" tabindex="-1" role="dialog" aria-labelledby="mahasiswaeditlabel" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="mahasiswaeditlabel">edit Data Mahasiswa Sistem Informasi</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>

                                                            <form action="<?= base_url('data/updateAjar') ?>" method="post">
                                                                <div class="modal-body">
                                                                    <div class="form-group">
                                                                        <input type="text" class="form-control" id="nim" placeholder="Nim" name="nim" value="<?= $sm->nim; ?>" readonly required>

                                                                    </div>

                                                                    <div class="form-group">
                                                                        <input type="text" class="form-control" id="name" placeholder="Nama" name="name" value="<?= $sm->name; ?>" required>

                                                                    </div>

                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                                                </div>
                                                            </form>

                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- ------------------------------- ------------------------------------------------------------------------------------------------------------------------------------------->

                                            <?php } ?>
                                        </tbody>
                                    </table>
                                    <!-- ------------------------------- Tambah Mahasiswa ----------------------------------------------------------------------------------------------------------------------------------------- -->
                                    <div class="modal fade" id="newSubMenuModal" tabindex="-1" role="dialog" aria-labelledby="newSubMenuModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="newSubMenuModalLabel">Tambah Data Mahasiswa 2016</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>

                                                <form action="<?= base_url('data/inputAjar'); ?>" method="post">
                                                    <div class="modal-body">

                                                        <div class="form-group">
                                                            <input type="text" class="form-control" id="thn_ajar" placeholder="Tahun AJar" name="thn_ajar" required>

                                                        </div>

                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Add</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>