<!-- Core -->
<script src="<?= base_url(); ?>assets/vendor/jquery/dist/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- Optional JS -->
<script src="<?= base_url(); ?>assets/vendor/chart.js/dist/Chart.min.js"></script>
<script src="<?= base_url(); ?>assets/vendor/chart.js/dist/Chart.extension.js"></script>

<script src="<?= base_url('assets'); ?>/js/sb-admin-2.min.js"></script>

<script src="<?= base_url(); ?>assets/vendor/chart.js/Chart.min.js"></script>
<script src="<?= base_url(); ?>assets/vendor/chart.js/Chart.js"></script>
<!-- Argon JS -->
<script src="<?= base_url(); ?>assets/js/demo/chart-area-demo.js"></script>
<script src="<?= base_url(); ?>assets/js/demo/chart-bar-demo.js"></script>
<script src="<?= base_url(); ?>assets/js/demo/chart-pie-demo.js"></script>

<script src="vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/chart-area-demo.js"></script>
<script src="js/demo/chart-pie-demo.js"></script>
<script src="js/demo/chart-bar-demo.js"></script>

<script src="<?= base_url(); ?>assets/js/argon.js?v=1.0.0"></script>

</body>
<div class="copyright text-center my-auto">
    <span>Copyright &copy; SI Kuisoner Bertha dan Fitri</span>
</div>

</html>