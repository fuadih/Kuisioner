<div class="main-content">
  <!-- Navbar -->

  <!-- Header -->
  <div class="header bg-gradient-primary py-7 py-lg-8">
    <div class="separator separator-bottom separator-skew zindex-100">
      <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <polygon class="fill-default" points="2560 0 2560 100 0 100"></polygon>
      </svg>
    </div>
  </div>
  <!-- Page content -->
  <div class="container mt--8 pb-5">
    <!-- Table -->
    <div class="row justify-content-center">
      <div class="col-lg-6 col-md-8">
        <div class="card bg-secondary shadow border-0">
          <div class="card-header bg-transparent pb-5">
            <div class="text-muted text-center mt-2 mb-4"><small>Sihlakan Registrasi</small></div>
            <div class="text-center">
              <a href="#" class="btn btn-neutral btn-icon mr-4">
                <span class="btn-inner--icon"><img src="../assets/img/icons/common/github.svg"></span>
                <span class="btn-inner--text">Fitur belum tersedia</span>
              </a>
              <a href="#" class="btn btn-neutral btn-icon">
                <span class="btn-inner--icon"><img src="../assets/img/icons/common/google.svg"></span>
                <span class="btn-inner--text">Fitur belum tersedia</span>
              </a>
            </div>
          </div>
          <div class="card-body px-lg-5 py-lg-5">
            <div class="text-center text-muted mb-4">
              <small>Or Daftar dengan membuat akun</small>
            </div>
            <form role="form" class="user" method="post" action="<?= base_url(); ?>auth/registration">
              <div class="form-group">
                <div class="input-group input-group-alternative mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text"><i class="ni ni-hat-3"></i></span>
                  </div>
                  <input class="form-control" placeholder="Nama depan" name="namadpn" type="text" value="<?= set_value('namadpn'); ?>">
                </div>
                <?= form_error('namadpn', '<small class="text-danger pl-3">', '</small>'); ?>
              </div>
              <div class="form-group">
                <div class="input-group input-group-alternative mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text"><i class="ni ni-hat-3"></i></span>
                  </div>
                  <input class="form-control" placeholder="Nama Belakang" name="namabelakang" type="text" value="<?= set_value('namabelakang'); ?>">
                </div>
                <?= form_error('namabelakang', '<small class="text-danger pl-3">', '</small>'); ?>
              </div>

              <div class="form-group">
                <div class="input-group input-group-alternative mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                  </div>
                  <input class="form-control" placeholder="Nim" name="nim" type="text" value="<?= set_value('nim'); ?>">
                </div>
                <?= form_error('nim', '<small class="text-danger pl-3">', '</small>'); ?>
              </div>
              <div class="form-group row">
                <div class="input-group col-sm-6 mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                  </div>
                  <input class="form-control" placeholder="Password" type="password" name="password1">
                </div>


                <div class="input-group col-sm-6 mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                  </div>
                  <input class="form-control" placeholder="Ulangi Password" type="password" name="password2">
                </div>
                <?= form_error('password1', '<small class="text-danger pl-3">', '</small>'); ?>
              </div>

              <div class="row my-4">
                <div class="col-12">
                  <div class="text-control">
                    <a href="<?= base_url(); ?>auth" class="text-muted"><small>Sudah Mempunyai akun? Login!</small></a>
                  </div>
                </div>
              </div>
              <div class="text-center">
                <button type="submit" class="btn btn-primary mt-4">Create account</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>