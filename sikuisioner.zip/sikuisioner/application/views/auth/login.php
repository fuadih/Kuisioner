<div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary py-7 py-lg-8">

        <div class="separator separator-bottom separator-skew zindex-100">
            <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg">
                <polygon class="fill-default" points="2560 0 2560 100 0 100"></polygon>
            </svg>
        </div>
    </div>
    <!-- Page content -->
    <div class="container mt--8 pb-5">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8">
                <div class="card bg-secondary shadow border-0">
                    <div class="card-header bg-transparent pb-5">
                        <div class="text-muted text-center mt-2 mb-4">
                            <h1 class="h4 text-gray-900 mb-4">LOGIN</h1>
                        </div>
                        <div class="text-center">
                            <a href="#" class="btn btn-neutral btn-icon mr-4">
                                <span class="btn-inner--icon"><img src="<?= base_url(); ?>assets/img/icons/common/github.svg"></span>
                                <span class="btn-inner--text">Fitur belum tersedia</span>
                            </a>
                            <a href="#" class="btn btn-neutral btn-icon">
                                <span class="btn-inner--icon"><img src="<?= base_url(); ?>assets/img/icons/common/google.svg"></span>
                                <span class="btn-inner--text">Fitur belum tersedia</span>
                            </a>
                        </div>
                    </div>
                    <div class="card-body px-lg-5 py-lg-5">
                        <div class="text-center text-muted mb-4">
                            <small>Or Login dengan akun</small>
                        </div>
                        <?= $this->session->flashdata('message'); ?>
                        <form role="form" class="user" method="post" action="<?= base_url('auth') ?>">
                            <div class="form-group mb-3">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                                    </div>
                                    <input class="form-control" placeholder="Email" name="nim" type="text" value="<?= set_value('nim'); ?>">
                                </div>
                                <?= form_error('nim', '<small class="text-danger pl-3">', '</small>'); ?>
                            </div>
                            <div class="form-group">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                    </div>
                                    <input class="form-control" placeholder="Password" type="password" name="password">
                                </div>
                                <?= form_error('password', '<small class="text-danger pl-3">', '</small>'); ?>
                            </div>

                            <div class="text-center">
                                <button type="submit" class="btn btn-primary my-2">Masuk</button>
                            </div>

                            <div class="text-control ">
                                <a href="#" class="text-muted"><small>Forgot password?</small></a>
                            </div>
                            <div class="text-control">
                                <a href="<?= base_url('auth/registration'); ?>" class="text-muted"><small>Create new account</small></a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer -->