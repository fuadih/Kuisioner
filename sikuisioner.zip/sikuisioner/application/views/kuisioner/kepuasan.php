<div class="main-content">
    <div class="header pb-8 pt-5 pt-lg-5 d-flex align-items-center">

        <div class="col-md">
            <h1 class="h3 mb-2 text-gray-800"><?= $title; ?></h1>
            <form action="<?php echo base_url() . 'kuisioner/input'; ?>" method="post">
                <div class="modal-body">
                    <div class="form-group row">
                        <label for="email" class="col-sm-2 col-form-label">Nim</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" id="nim" placeholder="Nim" name="nim" value="<?= $user['nim']; ?>" readonly required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="" class="col-sm-2 col-form-label">Nama Dosen</label>
                        <div class="col-sm-8">
                            <select name="nip" id="nip" class="form-control">
                                <?php foreach ($dosen as $m) { ?>
                                    <option value="<?= $m['nip']; ?>"><?= $m['dosen']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah Dosen tersebut memberikan pelayanan konsultasi dan bimbingan dalam kegiatan perwalian ?</label>
                        <div class="col-sm-10">
                            <select name="perwalian" id="perwalian" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah dosen menguasai materi kuliah pada saat mengajar?Apakah dosen menguasai materi kuliah pada saat mengajar?</label>
                        <div class="col-sm-10">
                            <select name="kp" id="kp" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi2 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah Dosen tersebut memberikan pelayanan konsultasi dan bimbingan dalam kegiatan Skripsi ?</label>
                        <div class="col-sm-10">
                            <select name="skripsi" id="skripsi" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi3 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah Dosen tersebut berpenampilan rapi saat bekerja?</label>
                        <div class="col-sm-10">
                            <select name="penampilan" id="penampilan" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi4 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah Dosen tersebut menerima kritik dengan terbuka?</label>
                        <div class="col-sm-10">
                            <select name="kritik" id="kritik" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi5 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah Ruang pelayanan Dosen tersebut terlihat bersih dan nyaman ?</label>
                        <div class="col-sm-10">
                            <select name="ruang" id="ruang" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi6 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah Dosen tersebut memiliki empati terhadap permasalahan mahasiswa ?</label>
                        <div class="col-sm-10">
                            <select name="empati" id="empati" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi7 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>


                    <div class="form-group row justify-content-end">
                        <div class="col-sm-12">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
            </form>
        </div>
    </div>
</div>