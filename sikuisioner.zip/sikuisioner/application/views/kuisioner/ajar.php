<div class="main-content">
    <div class="header pb-8 pt-5 pt-lg-5 d-flex align-items-center">

        <div class="col-md">
            <h1 class="h3 mb-2 text-gray-800"><?= $title; ?></h1>
            <form action="<?php echo base_url() . 'kuisioner/inputData'; ?>" method="post">
                <div class="modal-body">
                    <div class="form-group row">
                        <label for="email" class="col-sm-2 col-form-label">Nim</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" id="nim" placeholder="Nim" name="nim" value="<?= $user['nim']; ?>" readonly required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="" class="col-sm-2 col-form-label">Tahun Ajar</label>
                        <div class="col-sm-8">
                            <div class="form-group">
                                <select name="kd_thnajar" id="kd_thnajar" class="form-control" placeholder="" required>
                                    <option value="">-- Tahun AJar --</option>
                                    <?php
                             foreach($thnajar as $r){ // Lakukan looping pada variabel siswa dari controller
                       echo "<option value='".$r->kd_thnajar."'>".$r->thn_ajar."</option>";
                              }
                             ?>
                                   </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row" id="semester">
                        <label for="" class="col-sm-2 col-form-label">Semester</label>
                        <div class="col-sm-8">
                            <div class="form-group">
                                <select name="kd_smt" id="kd_smt" class="form-control" placeholder="" required>
                                    <option value="">-- Semester --</option>
                                     
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="" class="col-sm-2 col-form-label">MataKuliah</label>
                        <div class="col-sm-8">
                            <div class="form-group">
                                <select name="kd_matkul" id="kd_matkul" class="form-control" placeholder="" required>
                                    <option value="">-- Matakuliah --</option>
                                    
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="" class="col-sm-2 col-form-label">Nama Dosen</label>
                        <div class="col-sm-8">
                            <select name="nip" id="nip" class="form-control" placeholder="" required>
                                <option value="">-- Dosen --</option>

                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Bagaimana ketepatan waktu dosen dalam mengawali dan mengakhiri perkuliahan?</label>
                        <div class="col-sm-10">
                            <select name="waktu" id="waktu" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah dosen menguasai materi kuliah pada saat mengajar?</label>
                        <div class="col-sm-10">
                            <select name="materi" id="materi" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi2 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah dosen menyiapkan atau membawa berita acara perkuliahan dan daftar peserta?</label>
                        <div class="col-sm-10">
                            <select name="bap" id="bap" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi3 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah dosen memberikan tugas terstruktur dan tugas mandiri pada mahasiswa sesuai dengan bobot sks dan tujuan perkuliahan?</label>
                        <div class="col-sm-10">
                            <select name="tugas" id="tugas" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi4 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah dosen memberikan silabus, materi perkuliahan dan alat bantu pembelajaran?</label>
                        <div class="col-sm-10">
                            <select name="alat" id="alat" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi5 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah dosen mampu menciptakan suasana kelas yang kondusif dalam perkuliahan?</label>
                        <div class="col-sm-10">
                            <select name="suasana" id="suasana" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi6 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah dosen menerima saran dan kritik dari mahasiswa tentang upaya-upaya perbaikan kualitas pembelajaran?</label>
                        <div class="col-sm-10">
                            <select name="kritik" id="kritik" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi7 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah dosen memberikan pertemuan tambahan jika jumlah pertemuan belum mencapai 14 pertemuan?</label>
                        <div class="col-sm-10">
                            <select name="pertemuan" id="pertemuan" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi8 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Apakah ada transparansi dalam penetapan nilai akhir mahasiswa dan pengumuman nilai akhir kepada mahasiswa?</label>
                        <div class="col-sm-10">
                            <select name="transparansi" id="transparansi" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi9 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="">Bagaimana kesesuaian antara materi yang diujikan dengan materi kuliah yang disampaikan?
                        </label>
                        <div class="col-sm-10">
                            <select name="kesesuaian" id="kesesuaian" class="form-control" placeholder="" required>
                                <option value="">-- Nilai --</option>
                                <?php foreach ($opsi9 as $opsi) { ?>
                                    <option value="<?= $opsi['opsi']; ?>"><?= $opsi['nilai']; ?></option>
                                <?php } ?>
                            </select>
                            </option>
                        </div>
                    </div>
                </div>

                <div class="form-group row justify-content-end">
                    <div class="col-sm-12">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="<?php echo base_url("js/jquery.min.js"); ?>" type="text/javascript"></script>
  
  <script>
  jQuery(document).ready(function($){ 
   $(function(){
     $.ajaxSetup({
        type: "POST",
        url:"<?php echo base_url('index.php/kuisioner/ambil_data') ?>",
        cache:false,
    });
    
    $("#kd_thnajar").change(function(){ // Ketika user mengganti atau 
        // var value=$(this).val();
        var value= $("#kd_thnajar").val();
        if(value>0){
            $.ajax({
                data:{modul:'semester', id:value},
                success:function(response){
                    $("#kd_smt").html(response);
                }
            })
        }
        });
      $("#kd_smt").change(function(){ // Ketika user mengganti atau 
        // var value=$(this).val();
        var value= $("#kd_smt").val();
        if(value>0){
            $.ajax({
                data:{modul:'matkul', id:value},
                success:function(response){
                    $("#kd_matkul").html(response);
                }
            })
        }
        });

      $("#kd_matkul").change(function(){ // Ketika user mengganti atau 
        // var value=$(this).val();
        var value= $("#kd_matkul").val();
        if(value>0){
            $.ajax({
                data:{modul:'dosen', id:value},
                success:function(response){
                    $("#nip").html(response);
                }
            })
        }
        });

   })
  });
  </script>
